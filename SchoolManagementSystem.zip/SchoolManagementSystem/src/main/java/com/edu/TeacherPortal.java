package com.edu;

import java.sql.SQLException;
import java.util.Scanner;

public class TeacherPortal {
	 public void teacherportal() throws SQLException {
			int ch;
			Scanner sc=new Scanner(System.in);
			for(;;) {
				System.out.println("-----Welcome to School management System-------");
	        System.out.println("************Menu************");
	        System.out.println("Enter your choice");
	        System.out.println("1. Show Teachers details");
	        System.out.println("2. Register Teacher");
	        System.out.println("3. Delete Teachers");
	        System.out.println("4. Update Details");
	        System.out.println("5. Exit");
	        
	        ch=sc.nextInt();

	        switch(ch){
	        	case 1://Display Student details
	        		TeacherDBOperation.displayTeacherDatials();
	        		break;
	        		
	        	case 2:
	        		TeacherDBOperation.registerTeacher();
	        		break;
	        	case 3:
	        		TeacherDBOperation.deleteTeacher();
	        		break;
	        	case 4:
	        		TeacherDBOperation.updateTeacher();
	        		break;
	        	case 5:
	        		System.out.println("Thank you");
	        		System.exit(0);
	        		break;
	    
	                 }
	        }

	 }

}
