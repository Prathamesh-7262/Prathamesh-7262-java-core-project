package com.edu;

import java.sql.SQLException;

import java.util.Scanner;

public class MainStudentApp {

	public static void main(String[] args) throws SQLException {
		
		// TODO Auto-generated method stub
		int ch;
		Scanner sc=new Scanner(System.in);
		for(;;) {
        System.out.println("************Menu************");
        System.out.println("Enter your choice");
        System.out.println("1. Show student details");
        System.out.println("2. Register Student");
        System.out.println("3. Delete Student");
        System.out.println("4. Update Details");
        System.out.println("5. Exit");
        
        ch=sc.nextInt();

        switch(ch){
        	case 1://Display Student details
        		DatabaseOpertion.displayStudentDatials();
        		break;
        		
        	case 2:
        		DatabaseOpertion.registerStudent();
        		break;
        	case 3:
        		DatabaseOpertion.deleteStudent();
        		break;
        	case 4:
        		DatabaseOpertion.updateStudent();
        		break;
        	case 5:
        		System.exit(0);
        		break;
    
                 }
        }
		
		
        
	}

}
