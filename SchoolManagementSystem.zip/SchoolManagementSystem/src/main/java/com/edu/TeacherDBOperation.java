package com.edu;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class TeacherDBOperation {
	private static Connection conn;
    private static Statement stmt;
    private static String sql;
    private static ResultSet rs;
    public static PreparedStatement pst;
    
    public static void displayTeacherDatials() throws SQLException {
		// TODO Auto-generated method stub
		conn=DatabaseConnection.getConnection();
		
		stmt=conn.createStatement();
		
		sql="select * from teacher";
		
		rs=stmt.executeQuery(sql);
		System.out.println("Id\tName\tSalary\tDepartment");
		while(rs.next()) {
			int id=rs.getInt("id");
			String name=rs.getString("name");
			String sal=rs.getString("salary");
			String dept=rs.getString("department");
			
			System.out.println(id+"\t"+name+"\t"+sal+"\t"+dept+"\t");
			
		}
		
		
	}

	public static void registerTeacher() throws SQLException {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		conn=DatabaseConnection.getConnection();
		System.out.println("Enter Teacher name");
		String name=sc.next();
		System.out.println("enter salary");
		String sal=sc.next();
		System.out.println("Enter department");
		String dept=sc.next();
		stmt=conn.createStatement();
		String s = "select max(id)+1  as tid from teacher";
		rs=stmt.executeQuery(s);
		int stid=0;
		if(rs.next()) {
			stid=rs.getInt("tid");
		}
		
		sql="insert into teacher(id,name,salary,department)values(?,?,?,?)";
		pst=conn.prepareStatement(sql);
		pst.setInt(1,stid);
		pst.setString(2,name);
		pst.setString(3,sal);
		pst.setString(4,dept);
		
		int i=pst.executeUpdate();
		if(i>0) {
			System.out.println("Teacher registred succefull");
		}
		else {
			System.out.println("error");
		}
		
	}

	public static void deleteTeacher() throws SQLException {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		conn=DatabaseConnection.getConnection();
		System.out.println("Enter name to delete");
		String name=sc.next();
		stmt=conn.createStatement();
		String s="select * from teacher where name='"+name+"'";
		rs=stmt.executeQuery(s);
		if(rs.next()) {
			String del="delete from teacher where name='"+name+"'";
			int r=stmt.executeUpdate(del);
			if(r>0) {
				System.out.println("Records deleted successfully");
				
			}
			else {
				System.out.println("error");
			}
		}
		else {
			System.out.println("No user found");
		}
		
		
	}

	public static void updateTeacher() throws SQLException {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		conn=DatabaseConnection.getConnection();
		
		System.out.println("Enter id to update");
		String id=sc.next();
		
		stmt=conn.createStatement();
		String s="select * from teacher where id='"+id+"'";
		rs=stmt.executeQuery(s);
		
		if(rs.next()) {
			System.out.println("Enter your choice for update");
			System.out.println("1.To update name");
			System.out.println("2.To update salary");
			System.out.println("3.To update dept");
			int choice=sc.nextInt();
			switch(choice) {
			case 1:System.out.println("enter name to update");
			String name=sc.next();
			String sql="update teacher set name=? where id=?";
			pst=conn.prepareStatement(sql);
			pst.setString(1,name);
			pst.setString(2,id);
			int i=pst.executeUpdate();
			if(i>0) {
				System.out.println("Name is changed");
			}
			break;
			case 2:System.out.println("enter salary to update");
			String sal=sc.next();
			String sql1="update teacher set salary=? where id=?";
			pst=conn.prepareStatement(sql1);
			pst.setString(1,sal);
			pst.setString(2,id);
			int j=pst.executeUpdate();
			if(j>0) {
				System.out.println("salary is changed");
			}
			break;
			case 3:System.out.println("enter department to update");
			String dept=sc.next();
			String sql2="update teacher set department=? where id=?";
			pst=conn.prepareStatement(sql2);
			pst.setString(1,dept);
			pst.setString(2,id);
			int k=pst.executeUpdate();
			if(k>0) {
				System.out.println("department are changed");
			}
			break;
			
			}	
		}
		else {
			System.out.println("No record found");
		}
		
	}

}
