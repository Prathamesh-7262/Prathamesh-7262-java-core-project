package com.edu;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;


public class SchoolManagementSystem {

	public static void main(String[] args) throws SQLException, ClassNotFoundException {
	
		String driver="com.mysql.cj.jdbc.Driver";
		String url="jdbc:mysql://localhost:3306/batch10426";
		String un="root";
		String pass="root";
		Scanner sc =new Scanner(System.in);
		
		Connection conn=null;
		Statement stmt=null;
		
		String username,password;
		System.out.println("---Welcome To school management System----");
		System.out.println("Enter username for login");
		username=sc.next();
		
		System.out.println("Enter password for login");
		password=sc.next();
		
		
		Class.forName(driver);
		
		conn=DriverManager.getConnection(url,un,pass);
		
		stmt=conn.createStatement();
		
		String s="select * from login where username='"+username+"' and password='"+password+"' ";
		
		ResultSet rs=stmt.executeQuery(s);
		
		if(rs.next()) {
			System.out.println("Login successfull");
			for(;;) {
				System.out.println("Enter Your Choice to Continue");
				System.out.println("1.View Student Portal");
				System.out.println("2.View Teacher Portal");
				System.out.println("3.Exit");
			    int choice;
			    choice=sc.nextInt();
			    switch(choice) {
			    case 1:
//			    	StudentPortal.studentPortal();
			    	StudentPortal sobj=new StudentPortal();
			    	sobj.studentPortal();
			    	break;
			    case 2:
			    	TeacherPortal tobj=new TeacherPortal();
			    	tobj.teacherportal();
			    	break;
			    case 3:
			    	break;
			    }
				}
		}
		
		else {
			System.out.println("User not registered please register first");
		}
	}


}
