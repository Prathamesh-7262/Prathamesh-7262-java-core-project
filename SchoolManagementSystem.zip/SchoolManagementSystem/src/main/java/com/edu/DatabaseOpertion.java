package com.edu;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Date;
import java.util.Scanner;

public class DatabaseOpertion {
	private static Connection conn;
    private static Statement stmt;
    private static String sql;
    private static ResultSet rs;
    public static PreparedStatement pst;

	public static void displayStudentDatials() throws SQLException {
		// TODO Auto-generated method stub
		conn=DatabaseConnection.getConnection();
		
		stmt=conn.createStatement();
		
		sql="select * from students";
		
		rs=stmt.executeQuery(sql);
		System.out.println("Id\tName\tEmail\t\tFees\t\tdob");
		while(rs.next()) {
			int id=rs.getInt("id");
			String name=rs.getString("name");
			String email=rs.getString("email");
			float fees=rs.getFloat("fees");
			Date dob=rs.getDate("dob");
			
			System.out.println(id+"\t"+name+"\t"+email+"\t"+fees+"\t"+dob);
			
		}
		
		
	}

	public static void registerStudent() throws SQLException {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		conn=DatabaseConnection.getConnection();
		System.out.println("Enter student name");
		String name=sc.next();
		System.out.println("enter email");
		String email=sc.next();
		System.out.println("Enter fees");
		float fees=sc.nextFloat();
		System.out.println("Enter dob(yyyy-mm-dd)");
		String dob=sc.next();
		stmt=conn.createStatement();
		String s = "select max(id)+1  as sid from students";
		rs=stmt.executeQuery(s);
		int stid=0;
		if(rs.next()) {
			stid=rs.getInt("sid");
		}
		
		sql="insert into students(id,name,email,fees,dob)values(?,?,?,?,?)";
		pst=conn.prepareStatement(sql);
		pst.setInt(1,stid);
		pst.setString(2,name);
		pst.setString(3,email);
		pst.setFloat(4,fees);
		pst.setString(5,dob);
		
		int i=pst.executeUpdate();
		if(i>0) {
			System.out.println("Student registred succefull");
		}
		else {
			System.out.println("error");
		}
		
	}

	public static void deleteStudent() throws SQLException {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		conn=DatabaseConnection.getConnection();
		System.out.println("Enter name to delete");
		String name=sc.next();
		stmt=conn.createStatement();
		String s="select * from students where name='"+name+"'";
		rs=stmt.executeQuery(s);
		if(rs.next()) {
			String del="delete from students where name='"+name+"'";
			int r=stmt.executeUpdate(del);
			if(r>0) {
				System.out.println("Records deleted successfully");
				
			}
			else {
				System.out.println("error");
			}
		}
		else {
			System.out.println("No user found");
		}
		
		
	}

	public static void updateStudent() throws SQLException {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		conn=DatabaseConnection.getConnection();
		
		System.out.println("Enter id to update salary");
		String id=sc.next();
		
		stmt=conn.createStatement();
		String s="select * from students where id='"+id+"'";
		rs=stmt.executeQuery(s);
		
		if(rs.next()) {
			System.out.println("Enter your choice for update");
			System.out.println("1.To update name");
			System.out.println("2.To update emai");
			System.out.println("3.To update fees");
			System.out.println("4.To update date of birth");
			int choice=sc.nextInt();
			switch(choice) {
			case 1:System.out.println("enter name to update");
			String name=sc.next();
			String sql="update students set name=? where id=?";
			pst=conn.prepareStatement(sql);
			pst.setString(1,name);
			pst.setString(2,id);
			int i=pst.executeUpdate();
			if(i>0) {
				System.out.println("Name is changed");
			}
			break;
			case 2:System.out.println("enter email to update");
			String email=sc.next();
			String sql1="update students set email=? where id=?";
			pst=conn.prepareStatement(sql1);
			pst.setString(1,email);
			pst.setString(2,id);
			int j=pst.executeUpdate();
			if(j>0) {
				System.out.println("Email is changed");
			}
			break;
			case 3:System.out.println("enter fees to update");
			String fees=sc.next();
			String sql2="update students set fees=? where id=?";
			pst=conn.prepareStatement(sql2);
			pst.setString(1,fees);
			pst.setString(2,id);
			int k=pst.executeUpdate();
			if(k>0) {
				System.out.println("fees are changed");
			}
			break;
			
			case 4:System.out.println("enter dob to update");
			String dob=sc.next();
			String sql3="update students set name=? where id=?";
			pst=conn.prepareStatement(sql3);
			pst.setString(1,dob);
			pst.setString(2,id);
			int l=pst.executeUpdate();
			if(l>0) {
				System.out.println("dob is changed");
			}
			break;
			}	
		}
		else {
			System.out.println("No record found");
		}
		
	}



}
